PRIME FILE - WebIntoApp HTML project

IMPORTANT: index.html is at the ZIP root as required by WebIntoApp.
Open index.html to preview.

This is still a browser-only demo. Uploads are temporary and not shared with other visitors. Profile, Telegram link and changed creator code are saved only in this browser's local storage. Use a secure backend, database and cloud storage before public multi-user deployment.
